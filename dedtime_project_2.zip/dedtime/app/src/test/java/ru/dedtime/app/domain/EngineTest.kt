package ru.dedtime.app.domain

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import ru.dedtime.app.data.Category
import ru.dedtime.app.data.Habit
import ru.dedtime.app.data.HabitLog
import ru.dedtime.app.data.Purchase
import ru.dedtime.app.data.Session
import java.time.LocalDate
import java.time.ZoneId

class EngineTest {
    private val zone = ZoneId.of("Europe/Moscow")
    private val base = LocalDate.of(2026, 9, 24).atTime(12, 0).atZone(zone).toInstant().toEpochMilli()
    private val day = 86_400_000L
    private val now = base + 3_600_000L
    private val cats = listOf(Category(1, "Учёба", "accent", 0), Category(2, "Спорт", "#1D4ED8", 1), Category(3, "Чтение", "#F59E68", 2))
    private val week = (0 until 7).map { i ->
        val st = base - i * day
        Session(id = i + 1L, categoryId = 1, startedAt = st, endedAt = st + 30 * 60_000L)
    }

    @Before
    fun setUp() { Days.zone = zone }

    @Test
    fun streakAndHabits() {
        val habits = listOf(Habit(1, "Зарядка", xp = 20), Habit(2, "Вода", kind = Habit.KIND_COUNTER, target = 8, xp = 15))
        val logs = listOf(HabitLog(1, 1, "2026-09-24", 1), HabitLog(2, 2, "2026-09-24", 8))
        val st = Engine.compute(week, habits, logs, emptyList(), emptyList(), cats, now)
        assertEquals(7, st.streak)
        assertEquals(30, st.todayFocusMin)
        assertEquals(2, st.todayHabitsDone)
        assertTrue(st.achievements.first { it.def.id == "week" }.reached)
    }

    @Test
    fun freezeCoversGap() {
        val gap = week.filter { it.id != 3L }
        assertEquals(2, Engine.compute(gap, emptyList(), emptyList(), emptyList(), emptyList(), cats, now).streak)
        val freeze = listOf(Purchase(1, 1, "freeze", "", 50, base - 10 * day))
        assertEquals(7, Engine.compute(gap, emptyList(), emptyList(), freeze, emptyList(), cats, now).streak)
    }

    @Test
    fun doubleXp() {
        val s = listOf(Session(1, 1, startedAt = base, endedAt = base + 30 * 60_000L))
        val a = Engine.compute(s, emptyList(), emptyList(), listOf(Purchase(1, 1, "double", "", 120, base - 1000)), emptyList(), cats, now)
        val b = Engine.compute(s, emptyList(), emptyList(), emptyList(), emptyList(), cats, now)
        assertEquals(30L, a.xp - b.xp)
        assertEquals(30, a.doubleMinutesLeft)
    }

    @Test
    fun pauseAndBoundary() {
        val paused = Session(10, 1, startedAt = base, pausedAt = base + 10 * 60_000L)
        assertEquals(10 * 60_000L, paused.activeMs(now))
        val late = LocalDate.of(2026, 9, 25).atTime(2, 0).atZone(zone).toInstant().toEpochMilli()
        assertEquals(LocalDate.of(2026, 9, 24), Days.of(late))
        assertEquals(1, Rules.levelFor(0))
        assertEquals(2, Rules.levelFor(150))
    }
}
